<?php

if (!defined('PAGE_MODULE_SCREEN_NAME')) {
    define('PAGE_MODULE_SCREEN_NAME', 'page');
}
