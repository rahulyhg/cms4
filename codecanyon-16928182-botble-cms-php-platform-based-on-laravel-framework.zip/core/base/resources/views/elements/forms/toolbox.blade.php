<div class="tools">
    <a href="#" class="collapse tip" title="Collapse/Expand" data-original-title="Collapse/Expand"></a>
    <a href="#" class="fullscreen tip" title="Full screen" data-original-title="Full screen"> </a>
</div>