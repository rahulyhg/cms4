{!! $dataTable->table(compact('id', 'class'), false) !!}
@section('javascript')
    {!! $dataTable->scripts() !!}
@stop