<?php

return [
    'send-fail' => 'Send email failed',
    'happy_birthday' => 'Happy birthday!',
];
