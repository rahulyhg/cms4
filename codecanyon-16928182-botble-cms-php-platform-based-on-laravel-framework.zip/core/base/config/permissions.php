<?php

return [
    [
        'name' => 'Plugins',
        'flag' => 'plugins.list',
        'parent_flag' => 'core.system',
    ],
    [
        'name' => 'System',
        'flag' => 'core.system',
    ],
    [
        'name' => 'Appearance',
        'flag' => 'core.appearance',
    ],
];