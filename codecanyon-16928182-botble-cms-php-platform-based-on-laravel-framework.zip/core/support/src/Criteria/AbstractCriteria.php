<?php

namespace Botble\Support\Criteria;

use Botble\Support\Criteria\Contracts\CriteriaContract;

abstract class AbstractCriteria implements CriteriaContract
{
}
