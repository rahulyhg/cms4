<?php

if (!defined('FILTER_PRE_DEFINED_WIDGETS')) {
    define('FILTER_PRE_DEFINED_WIDGETS', 'pre_defined_widgets');
}

if (!defined('WIDGET_MANAGER_MODULE_SCREEN_NAME')) {
    define('WIDGET_MANAGER_MODULE_SCREEN_NAME', 'widget-manager');
}

if (!defined('WIDGET_TOP_META_BOXES')) {
    define('WIDGET_TOP_META_BOXES', 'widget-top-meta-boxes');
}