<?php

return [
    [
        'name' => 'Widgets',
        'flag' => 'widgets.list',
        'parent_flag' => 'core.appearance',
    ],
];