<div class="panel panel-default">
    <div class="panel-title">
        <h3>{{ __($config['name']) }}</h3>
    </div>
    <div class="panel-content">
        <p>{!! $config['content'] !!}</p>
    </div>
</div>