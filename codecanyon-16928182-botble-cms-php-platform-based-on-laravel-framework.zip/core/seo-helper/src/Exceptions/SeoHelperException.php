<?php

namespace Botble\SeoHelper\Exceptions;

use Exception;

abstract class SeoHelperException extends Exception
{
}
