<?php

if (!defined('BASE_FILTER_AFTER_SETTING_CONTENT')) {
    define('BASE_FILTER_AFTER_SETTING_CONTENT', 'base-filter-after-setting-content');
}

if (!defined('BASE_FILTER_AFTER_SETTING_EMAIL_CONTENT')) {
    define('BASE_FILTER_AFTER_SETTING_EMAIL_CONTENT', 'base-filter-after-setting-email-content');
}