<?php

return [
    [
        'name' => 'Settings',
        'flag' => 'settings.options',
        'parent_flag' => 'core.system',
    ],
];