<?php

if (!defined('MENU_MODULE_SCREEN_NAME')) {
    define('MENU_MODULE_SCREEN_NAME', 'menu');
}

if (!defined('MENU_ACTION_SIDEBAR_OPTIONS')) {
    define('MENU_ACTION_SIDEBAR_OPTIONS', 'menu_sidebar_options');
}
