@foreach ($bodyScripts as $script)
    {!! Html::script($script) !!}
@endforeach