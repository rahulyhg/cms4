<?php

return [
    'theme' => 'Theme',
    'author' => 'Author',
    'version' => 'Version',
    'description' => 'Description',
    'active_success' => 'Active theme successfully!',
    'active' => 'Active',
    'activated' => 'Activated',
    'theme_options' => 'Theme options',
];
