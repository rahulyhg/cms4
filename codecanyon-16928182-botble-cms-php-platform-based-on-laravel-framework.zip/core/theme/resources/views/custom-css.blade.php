@extends('core.base::layouts.master')
@section('content')
    {!! $form->renderForm() !!}
@stop