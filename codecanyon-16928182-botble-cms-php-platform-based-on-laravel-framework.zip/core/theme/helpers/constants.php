<?php

if (!defined('THEME_FRONT_FOOTER')) {
    define('THEME_FRONT_FOOTER', 'theme-front-footer');
}

if (!defined('THEME_OPTIONS_MODULE_SCREEN_NAME')) {
    define('THEME_OPTIONS_MODULE_SCREEN_NAME', 'theme-options');
}

if (!defined('THEME_OPTIONS_ACTION_META_BOXES')) {
    define('THEME_OPTIONS_ACTION_META_BOXES', 'theme-options-action-meta-boxes');
}
