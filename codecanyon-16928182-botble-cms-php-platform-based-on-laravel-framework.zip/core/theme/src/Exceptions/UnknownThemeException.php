<?php

namespace Botble\Theme\Exceptions;

use UnexpectedValueException;

class UnknownThemeException extends UnexpectedValueException
{
}
