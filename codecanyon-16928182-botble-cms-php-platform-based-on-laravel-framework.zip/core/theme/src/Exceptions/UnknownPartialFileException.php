<?php

namespace Botble\Theme\Exceptions;

use UnexpectedValueException;

class UnknownPartialFileException extends UnexpectedValueException
{
}
