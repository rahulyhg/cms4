<?php

return [
    'pattern' => '--slug--',
    'supported' => [
        'page',
    ],
];
