<?php

namespace Botble\Slug\Repositories\Interfaces;

use Botble\Support\Repositories\Interfaces\RepositoryInterface;

interface SlugInterface extends RepositoryInterface
{
}
