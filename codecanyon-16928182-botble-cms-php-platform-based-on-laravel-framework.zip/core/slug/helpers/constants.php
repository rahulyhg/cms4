<?php

if (!defined('SLUG_MODULE_SCREEN_NAME')) {
    define('SLUG_MODULE_SCREEN_NAME', 'slug');
}

if (!defined('BASE_FILTER_SLUG_AREA')) {
    define('BASE_FILTER_SLUG_AREA', 'slug-area');
}
