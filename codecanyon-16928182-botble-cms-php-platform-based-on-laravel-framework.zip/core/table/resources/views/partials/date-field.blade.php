<div class="input-group">
    {!! $content !!}
    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
</div>